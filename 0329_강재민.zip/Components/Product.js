import React from 'react';
import ProductChild from './ProductChild';

function Product(props) {
  return (
    <>
      <ProductChild />
    </>
  );
}

export default Product;