import React from 'react';

function FleaMarket(props) {
  return (
    <>
      <p>
        알뜰쇼핑이어라~
      </p>
    </>
  );
}

export default FleaMarket;