import React from 'react';

function Best(props) {
  return (
    <>
      <p>
        베스트 상품이어라~
      </p>
    </>
  );
}

export default Best;