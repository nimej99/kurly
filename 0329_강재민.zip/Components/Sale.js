import React from 'react';

function Sale(props) {
  return (
    <>
      <p>
        특가 / 혜택이어라~
      </p>
    </>
  );
}

export default Sale;