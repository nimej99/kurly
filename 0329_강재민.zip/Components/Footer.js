import React from 'react';

function Footer(props) {
  return (
    <>
      <footer>
        <address>
          Copyright &copy; 2023 kurly allrights reserved.
        </address>
      </footer>
    </>
  );
}

export default Footer;